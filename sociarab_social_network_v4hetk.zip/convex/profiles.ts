import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const get = query({
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!profile) return null;

    const storageUrl = profile.avatarUrl 
      ? await ctx.storage.getUrl(profile.avatarUrl)
      : null;

    return { ...profile, avatarUrl: storageUrl };
  },
});

export const getById = query({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", args.userId))
      .first();

    if (!profile) return null;

    const storageUrl = profile.avatarUrl 
      ? await ctx.storage.getUrl(profile.avatarUrl)
      : null;

    return { ...profile, avatarUrl: storageUrl };
  },
});

export const create = mutation({
  args: {
    name: v.string(),
    interests: v.array(v.string()),
    bio: v.optional(v.string()),
    avatarUrl: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("يجب تسجيل الدخول");

    const existing = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (existing) {
      throw new Error("لديك ملف شخصي بالفعل");
    }

    return await ctx.db.insert("profiles", {
      userId,
      name: args.name,
      interests: args.interests,
      bio: args.bio,
      avatarUrl: args.avatarUrl,
    });
  },
});

export const generateUploadUrl = mutation({
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("يجب تسجيل الدخول");
    return await ctx.storage.generateUploadUrl();
  },
});
