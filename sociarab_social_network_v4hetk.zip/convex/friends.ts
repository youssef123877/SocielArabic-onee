import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const sendRequest = mutation({
  args: { toUserId: v.id("users") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("يجب تسجيل الدخول");

    const existing = await ctx.db
      .query("friendships")
      .withIndex("by_users", (q) => 
        q.eq("userId1", userId).eq("userId2", args.toUserId)
      )
      .first();

    if (existing) {
      throw new Error("تم إرسال طلب الصداقة مسبقاً");
    }

    return await ctx.db.insert("friendships", {
      userId1: userId,
      userId2: args.toUserId,
      status: "pending",
    });
  },
});

export const acceptRequest = mutation({
  args: { requestId: v.id("friendships") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("يجب تسجيل الدخول");

    const request = await ctx.db.get(args.requestId);
    if (!request || request.userId2 !== userId) {
      throw new Error("طلب صداقة غير صالح");
    }

    await ctx.db.patch(args.requestId, { status: "accepted" });
  },
});

export const listFriends = query({
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const friendships = await ctx.db
      .query("friendships")
      .withIndex("by_user1", (q) => q.eq("userId1", userId))
      .filter((q) => q.eq(q.field("status"), "accepted"))
      .collect();

    return Promise.all(
      friendships.map(async (friendship) => {
        const friend = await ctx.db.get(friendship.userId2);
        const profile = await ctx.db
          .query("profiles")
          .withIndex("by_user", (q) => q.eq("userId", friendship.userId2))
          .first();
        return { ...friend, profile };
      })
    );
  },
});
