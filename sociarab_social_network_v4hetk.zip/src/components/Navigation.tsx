import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

export function Navigation() {
  const profile = useQuery(api.profiles.get);
  
  if (!profile) return null;

  return (
    <nav className="hidden lg:block space-y-2">
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex items-center gap-3 mb-4">
          {profile.avatarUrl ? (
            <img
              src={profile.avatarUrl}
              alt={profile.name}
              className="w-12 h-12 rounded-full object-cover"
            />
          ) : (
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
              {profile.name[0]}
            </div>
          )}
          <div>
            <div className="font-semibold">{profile.name}</div>
            {profile.bio && (
              <div className="text-sm text-gray-500">{profile.bio}</div>
            )}
          </div>
        </div>

        <div className="space-y-1">
          <button className="w-full text-right py-2 px-3 rounded-lg hover:bg-gray-50 flex items-center gap-2">
            <img src="/icons/home.png" alt="" className="w-5 h-5" />
            <span>الرئيسية</span>
          </button>
          <button className="w-full text-right py-2 px-3 rounded-lg hover:bg-gray-50 flex items-center gap-2">
            <img src="/icons/profile.png" alt="" className="w-5 h-5" />
            <span>الملف الشخصي</span>
          </button>
          <button className="w-full text-right py-2 px-3 rounded-lg hover:bg-gray-50 flex items-center gap-2">
            <img src="/icons/friends.png" alt="" className="w-5 h-5" />
            <span>الأصدقاء</span>
          </button>
        </div>
      </div>
    </nav>
  );
}
