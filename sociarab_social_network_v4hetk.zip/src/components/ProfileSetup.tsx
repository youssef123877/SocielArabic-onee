import { useState, useRef } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

const INTERESTS = [
  "الرياضة",
  "التكنولوجيا",
  "الفن",
  "الطبخ",
  "السفر",
  "الأدب",
  "الموسيقى",
  "الأفلام",
];

export function ProfileSetup() {
  const [name, setName] = useState("");
  const [bio, setBio] = useState("");
  const [interests, setInterests] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const fileInput = useRef<HTMLInputElement>(null);

  const createProfile = useMutation(api.profiles.create);
  const generateUploadUrl = useMutation(api.profiles.generateUploadUrl);

  const handleImageUpload = async (file: File) => {
    setIsUploading(true);
    try {
      const postUrl = await generateUploadUrl();
      const result = await fetch(postUrl, {
        method: "POST",
        headers: { "Content-Type": file.type },
        body: file,
      });
      const { storageId } = await result.json();
      setAvatarUrl(storageId);
    } catch (error) {
      toast.error("فشل رفع الصورة");
    } finally {
      setIsUploading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name) return;

    try {
      await createProfile({
        name,
        bio,
        interests,
        avatarUrl: avatarUrl ?? undefined,
      });
      toast.success("تم إنشاء ملفك الشخصي بنجاح");
    } catch (error) {
      toast.error("حدث خطأ أثناء إنشاء الملف الشخصي");
    }
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-2xl font-bold text-center mb-6">إعداد ملفك الشخصي</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="flex justify-center mb-4">
          <div className="relative">
            {avatarUrl ? (
              <img
                src={avatarUrl}
                alt="الصورة الشخصية"
                className="w-24 h-24 rounded-full object-cover"
              />
            ) : (
              <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center">
                <img src="/icons/profile.png" alt="" className="w-12 h-12" />
              </div>
            )}
            <button
              type="button"
              onClick={() => fileInput.current?.click()}
              className="absolute bottom-0 right-0 bg-green-600 text-white p-2 rounded-full"
            >
              <img src="/icons/camera.png" alt="" className="w-4 h-4" />
            </button>
            <input
              type="file"
              ref={fileInput}
              accept="image/*"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) handleImageUpload(file);
              }}
              className="hidden"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">اسمك</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full p-2 border rounded-lg"
            placeholder="أدخل اسمك"
            required
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium mb-1">نبذة عنك</label>
          <textarea
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            className="w-full p-2 border rounded-lg h-24"
            placeholder="اكتب نبذة قصيرة عن نفسك"
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">اهتماماتك</label>
          <div className="flex flex-wrap gap-2">
            {INTERESTS.map((interest) => (
              <button
                key={interest}
                type="button"
                onClick={() => {
                  if (interests.includes(interest)) {
                    setInterests(interests.filter((i) => i !== interest));
                  } else {
                    setInterests([...interests, interest]);
                  }
                }}
                className={`px-3 py-1 rounded-full text-sm ${
                  interests.includes(interest)
                    ? "bg-green-600 text-white"
                    : "bg-gray-100"
                }`}
              >
                {interest}
              </button>
            ))}
          </div>
        </div>

        <button
          type="submit"
          disabled={!name || isUploading}
          className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 disabled:opacity-50"
        >
          {isUploading ? "جاري الرفع..." : "إنشاء الملف الشخصي"}
        </button>
      </form>
    </div>
  );
}
