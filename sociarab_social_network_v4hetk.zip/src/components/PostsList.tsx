import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

export function PostsList() {
  const posts = useQuery(api.posts.list);

  if (!posts) {
    return (
      <div className="flex justify-center items-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {posts.map((post) => (
        <div key={post._id} className="bg-white rounded-lg shadow p-4">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
              {post.author?.name?.[0] ?? "؟"}
            </div>
            <div>
              <div className="font-semibold">{post.author?.name ?? "مستخدم"}</div>
              <div className="text-sm text-gray-500">
                {new Date(post._creationTime).toLocaleDateString("ar-SA")}
              </div>
            </div>
          </div>
          <p className="text-gray-800">{post.content}</p>
          <div className="mt-3 flex items-center gap-4 text-sm text-gray-500">
            <span>👍 {post.likesCount}</span>
            <span>💬 {post.commentsCount}</span>
          </div>
        </div>
      ))}
    </div>
  );
}
