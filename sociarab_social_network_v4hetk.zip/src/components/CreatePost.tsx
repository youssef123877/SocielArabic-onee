import { useState, useRef } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function CreatePost() {
  const [content, setContent] = useState("");
  const [isUploading, setIsUploading] = useState(false);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const fileInput = useRef<HTMLInputElement>(null);
  
  const createPost = useMutation(api.posts.create);
  const generateUploadUrl = useMutation(api.profiles.generateUploadUrl);

  const handleImageUpload = async (file: File) => {
    setIsUploading(true);
    try {
      const postUrl = await generateUploadUrl();
      const result = await fetch(postUrl, {
        method: "POST",
        headers: { "Content-Type": file.type },
        body: file,
      });
      const { storageId } = await result.json();
      setImageUrl(storageId);
    } catch (error) {
      toast.error("فشل رفع الصورة");
    } finally {
      setIsUploading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;

    try {
      await createPost({ content, imageUrl: imageUrl ?? undefined });
      setContent("");
      setImageUrl(null);
      if (fileInput.current) fileInput.current.value = "";
      toast.success("تم نشر المنشور بنجاح");
    } catch (error) {
      toast.error("حدث خطأ أثناء النشر");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow p-4">
      <textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder="ماذا يدور في ذهنك؟"
        className="w-full p-2 border rounded-lg resize-none h-24"
        dir="rtl"
      />
      <div className="mt-2 flex items-center justify-between">
        <input
          type="file"
          ref={fileInput}
          accept="image/*"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) handleImageUpload(file);
          }}
          className="text-sm"
        />
        <button
          type="submit"
          disabled={!content.trim() || isUploading}
          className="bg-green-600 text-white px-4 py-2 rounded-lg disabled:opacity-50"
        >
          {isUploading ? "جاري الرفع..." : "نشر"}
        </button>
      </div>
      {imageUrl && (
        <div className="mt-2">
          <img
            src={imageUrl}
            alt="المرفق"
            className="max-h-40 rounded-lg object-cover"
          />
        </div>
      )}
    </form>
  );
}
