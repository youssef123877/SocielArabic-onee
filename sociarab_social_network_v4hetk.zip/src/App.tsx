import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { CreatePost } from "./components/CreatePost";
import { PostsList } from "./components/PostsList";
import { ProfileSetup } from "./components/ProfileSetup";
import { Navigation } from "./components/Navigation";

export default function App() {
  const loggedInUser = useQuery(api.auth.loggedInUser);

  return (
    <div className="min-h-screen flex flex-col" dir="rtl">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm p-4 flex justify-between items-center border-b">
        <div className="flex items-center gap-2">
          <img
            src="/logo.png"
            alt="SociArab"
            className="h-8 w-8"
          />
          <h2 className="text-xl font-semibold text-green-600">SociArab</h2>
        </div>
        {loggedInUser && <SignOutButton />}
      </header>

      <main className="flex-1 p-4">
        <Authenticated>
          <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-[250px_1fr_250px] gap-4">
            <Navigation />
            <div className="space-y-4">
              <Content />
            </div>
            <div className="hidden lg:block">
              {/* سيتم إضافة اقتراحات الأصدقاء هنا */}
            </div>
          </div>
        </Authenticated>
        
        <Unauthenticated>
          <div className="max-w-md mx-auto text-center">
            <div className="mb-8">
              <img
                src="/logo.png"
                alt="SociArab"
                className="w-32 h-32 mx-auto mb-4"
              />
              <h1 className="text-4xl font-bold text-green-600 mb-2">SociArab</h1>
              <p className="text-slate-600">تواصل مع العالم العربي</p>
            </div>
            <SignInForm />
          </div>
        </Unauthenticated>
      </main>

      <footer className="text-center p-4 text-sm text-gray-500 border-t">
        تم تطوير الموقع بواسطة يوسف مشهوري © {new Date().getFullYear()}
      </footer>
      <Toaster />
    </div>
  );
}

function Content() {
  const profile = useQuery(api.profiles.get);

  if (profile === undefined) {
    return (
      <div className="flex justify-center items-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-500"></div>
      </div>
    );
  }

  return profile ? (
    <div className="space-y-6">
      <CreatePost />
      <PostsList />
    </div>
  ) : (
    <ProfileSetup />
  );
}
